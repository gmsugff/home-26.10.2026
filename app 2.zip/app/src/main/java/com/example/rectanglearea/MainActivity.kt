package com.example.rectanglearea

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var editTextLength: EditText
    private lateinit var editTextWidth: EditText
    private lateinit var textViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        editTextLength = findViewById(R.id.editTextLength)
        editTextWidth = findViewById(R.id.editTextWidth)
        textViewResult = findViewById(R.id.textViewResult)

        findViewById<Button>(R.id.buttonCalculate).setOnClickListener {
            calculateResult()
        }
    }

    private fun calculateResult() {
        val length = editTextLength.text.toString().toDoubleOrNull()
        val width = editTextWidth.text.toString().toDoubleOrNull()

        if (length == null || width == null) {
            Toast.makeText(this, R.string.error_invalid_input, Toast.LENGTH_SHORT).show()
            return
        }

        if (length <= 0 || width <= 0) {
            Toast.makeText(this, R.string.error_positive_values, Toast.LENGTH_SHORT).show()
            return
        }

        val area = length * width
        textViewResult.text = getString(R.string.result_format, area)
    }
}